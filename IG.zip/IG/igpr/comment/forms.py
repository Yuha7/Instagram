from django import forms
from comment.models import Comment
from django.contrib.auth.models import User


class NewCommentForm(forms.ModelForm):
    body = forms.CharField(widget=forms.TextInput(attrs={'class': 'input', 'placeholder': 'Enter Comment'}), required=True)

    class Meta:
        model = Comment
        fields = ['body']