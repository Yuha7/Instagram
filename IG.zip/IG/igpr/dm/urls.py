from django.urls import path
from dm.views import inbox, dm, SendDirect, UserSearch, NewConversation

urlpatterns=[
    path("", inbox, name="message"),
    path('direct/<username>',dm, name="DM"),
    path('send/', SendDirect, name="send-directs"),
    path('search/', UserSearch, name="search-users"),
    path('new/<username>', NewConversation, name="new-conversation"),
]