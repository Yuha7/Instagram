from django.contrib import admin
from dm.models import Message
# Register your models here.
admin.site.register(Message)
